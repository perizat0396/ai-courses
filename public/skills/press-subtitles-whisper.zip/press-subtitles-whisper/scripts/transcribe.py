"""Расшифровка аудио в SRT с короткими фразами (2–4 слова) для Reels.

Использование:
    python transcribe.py audio.wav --lang ru --model small --words 4
    --lang: ru | kk | auto
"""
import argparse
import sys


def ts(t: float) -> str:
    h, rem = divmod(t, 3600)
    m, s = divmod(rem, 60)
    return f"{int(h):02d}:{int(m):02d}:{int(s):02d},{int((s % 1) * 1000):03d}"


def main():
    p = argparse.ArgumentParser()
    p.add_argument("audio")
    p.add_argument("--lang", default="ru")
    p.add_argument("--model", default="small")
    p.add_argument("--words", type=int, default=4)
    a = p.parse_args()
    lang = None if a.lang == "auto" else a.lang

    words = []
    try:
        from faster_whisper import WhisperModel
        model = WhisperModel(a.model, device="cpu", compute_type="int8")
        segs, info = model.transcribe(a.audio, language=lang, word_timestamps=True, vad_filter=True)
        for s in segs:
            for w in s.words or []:
                words.append((w.start, w.end, w.word.strip()))
    except ImportError:
        import whisper
        model = whisper.load_model(a.model)
        r = model.transcribe(a.audio, language=lang, word_timestamps=True)
        for s in r["segments"]:
            for w in s.get("words", []):
                words.append((w["start"], w["end"], w["word"].strip()))

    if not words:
        sys.exit("Речь не распознана")

    base = a.audio.rsplit(".", 1)[0]
    chunks = [words[i:i + a.words] for i in range(0, len(words), a.words)]
    with open(base + ".srt", "w", encoding="utf-8") as f:
        for i, c in enumerate(chunks, 1):
            f.write(f"{i}\n{ts(c[0][0])} --> {ts(c[-1][1])}\n{' '.join(w[2] for w in c)}\n\n")
    with open(base + ".txt", "w", encoding="utf-8") as f:
        f.write(" ".join(w[2] for w in words))
    print(f"Готово: {base}.srt, {base}.txt — слов: {len(words)}")


if __name__ == "__main__":
    main()
