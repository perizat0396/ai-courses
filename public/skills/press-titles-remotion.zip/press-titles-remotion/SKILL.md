---
name: press-titles-remotion
description: Анимированные титры, заставки, плашки «спикер — должность», интро/аутро с логотипом и короткие моушн-ролики из текста и цифр для пресс-службы университета через Remotion (видео кодом на React). Используй, когда просят заставку, анимированный текст, нижнюю плашку с именем, итоги в цифрах, анонс мероприятия видеороликом, анимированную инфографику.
---

# Титры и моушн через Remotion (пресс-служба)

Remotion собирает видео из кода на React: текст, логотип, цвета бренда, анимация. Пользователь кода не видит — он даёт текст, цифры, логотип и получает MP4.

## Бренд университета — обязательно

- Логотип Amanzholov University есть в каждой композиции (в Intro/Outro — по центру крупно, в остальных — в углу ~12% ширины). Скопируй `assets/vku-logo-white.svg` и `assets/vku-logo-blue.svg` в `public/` проекта и подключай через `<Img src={staticFile('vku-logo-white.svg')} />`.
- Белый логотип — на синем или тёмном фоне, синий — на белом и светлом.
- Фирменный цвет: #004AAD (фон плашек, акценты), текст на нём — белый.
- Логотип не растягивать, не перекрашивать, не анимировать «вращением» — только плавное появление или масштаб.

## Где это работает

Рендер Remotion скачивает headless Chrome. В облачной песочнице чата это может быть заблокировано.
- **Лучший вариант** — Claude на компьютере (Claude Code или приложение с доступом к папке): Node.js 18+ установлен, всё скачивается.
- Если рендер в чате не запускается — скажи об этом одной строкой и предложи: (а) запустить на компьютере, (б) сделать тот же титр через FFmpeg `drawtext` (проще, без анимаций сложнее fade/slide), (в) сделать титр в CapCut по твоему ТЗ.

## Порядок работы

1. Собери вводные одним сообщением: формат (9:16 / 16:9 / 1:1), длительность (обычно 3–8 с для плашек, 15–30 с для итогов), тексты, цифры, логотип (PNG с прозрачностью), цвета бренда, язык (RU/KZ).
2. Создай проект: `npx create-video@latest --blank press-titles`, композиции пиши по шаблону ниже.
3. Сделай композицию по шаблону ниже, покажи кадр-превью: `npx remotion still <Comp> preview.png --frame=45`.
4. После одобрения: `npx remotion render <Comp> out.mp4 --codec=h264`.
5. Для плашки поверх видео рендери с прозрачностью: `--codec=prores --prores-profile=4444 --pixel-format=yuva444p10le` (файл .mov), потом наложи через FFmpeg overlay.

## Шаблоны (что предлагать)

| Шаблон | Что это | Длительность |
| --- | --- | --- |
| LowerThird | Плашка «Имя Фамилия — должность» снизу слева, выезжает и уезжает | 5 с |
| Intro | Логотип + название мероприятия, появление с масштабом | 3 с |
| Outro | Логотип, сайт, соцсети, «Подписывайтесь» | 4 с |
| Numbers | Итоги в цифрах: счётчики 0 → N («1200 абитуриентов») | 3 с на цифру |
| Announcement | Анонс: дата, время, место, QR | 8–10 с |
| Quote | Цитата спикера крупно + фото | 6 с |

## Базовая композиция (LowerThird)

```tsx
import {AbsoluteFill, interpolate, spring, useCurrentFrame, useVideoConfig} from 'remotion';

export const LowerThird: React.FC<{name: string; role: string; color: string}> = ({name, role, color}) => {
  const frame = useCurrentFrame();
  const {fps, durationInFrames} = useVideoConfig();
  const enter = spring({frame, fps, config: {damping: 200}});
  const exit = interpolate(frame, [durationInFrames - 15, durationInFrames], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  const x = interpolate(enter - exit, [0, 1], [-700, 0]);
  return (
    <AbsoluteFill style={{justifyContent: 'flex-end', padding: 80}}>
      <div style={{transform: `translateX(${x}px)`, fontFamily: 'Montserrat, DejaVu Sans, sans-serif'}}>
        <div style={{background: color, color: '#fff', fontSize: 54, fontWeight: 800, padding: '14px 28px', display: 'inline-block'}}>{name}</div>
        <div style={{background: '#fff', color: '#111', fontSize: 34, padding: '10px 28px', display: 'inline-block', marginTop: 6}}>{role}</div>
      </div>
    </AbsoluteFill>
  );
};
```
Регистрируй в `Root.tsx` через `<Composition id="LowerThird" component={LowerThird} durationInFrames={150} fps={30} width={1920} height={1080} defaultProps={{...}} />`.

## Правила дизайна

- Цвета — фирменные (#004AAD + белый); шрифт уточни у пользователя, если не дан — Montserrat.
- Текст крупный: минимум 48 px для 1080 по ширине, контраст не ниже 4.5:1.
- Казахские буквы: проверь шрифт на «ә ғ қ ң ө ұ ү һ і» на превью.
- Безопасная зона для Reels: ничего важного в нижних 350 px и верхних 250 px (1080×1920).
- Анимации короткие: вход 0.4–0.6 с, выход 0.3–0.5 с; без мигания.
- Фамилии и должности сверяй с пользователем — опечатка в должности ректора хуже, чем отсутствие титра.
