#!/usr/bin/env bash
# Проверка готового видео: параметры + 3 кадра (начало, середина, конец)
# Использование: bash check.sh out.mp4
set -e
f="$1"
ffprobe -v error -show_entries format=duration,size:stream=codec_type,width,height -of default=nw=1 "$f"
d=$(ffprobe -v error -show_entries format=duration -of csv=p=0 "$f")
for p in 0.1 0.5 0.9; do
  t=$(awk "BEGIN{print $d*$p}")
  ffmpeg -v error -y -ss "$t" -i "$f" -frames:v 1 -vf scale=480:-2 "check_${p}.jpg"
done
echo "Кадры: check_0.1.jpg check_0.5.jpg check_0.9.jpg"
